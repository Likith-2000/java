package zoo.food;
import java.util.Scanner;  
public class Hotel {
    int choice;  
    String menu;  
    void show() {  
     var s = new Scanner(System.in);  
     System.out.println("Enter your choice");  
     System.out.println("Enter 1 for veg");  
     System.out.println("Enter 2 for non veg");  
     System.out.println("Enter 3 for ice cream");  
     choice = s.nextInt();  
     if (choice == 1) {  
      System.out.println("you have select veg");  
      System.out.println("menu");  
      menu = s.nextLine();  
     }  
     if (choice == 2) {  
      System.out.println("you have select non veg");  
      System.out.println("menu");  
      menu = s.nextLine();  
     }  
     if (choice == 3) {  
      System.out.println("you have select icecream");  
      System.out.println("menu");  
      menu = s.nextLine();  
     }  
    }  
    public static void main(String[] args) {  
     Hotel h = new Hotel();  
     h.show();  
    }  
   }   
    

