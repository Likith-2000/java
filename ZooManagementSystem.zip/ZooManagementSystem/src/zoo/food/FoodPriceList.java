package zoo.food;

public class FoodPriceList 
 {
    public void  Veg()
    {
        System.out.println("full meals Veg price  : 100rs");
        System.out.println("half meals Veg price  : 50rs");
    }

    public void nonveg()
    {
        System.out.println(" Biriyani:200rs");
        System.out.println(" biriyan rice:100rs");
        System.out.println(" tandorii:300rs");
        System.out.println("kabeb:50rs");
        System.out.println(" curry:750rs");
    };
    
    
    public void chinese()
    {
        System.out.println(" noddels:200rs");
        System.out.println(" shawarma:100rs");
        System.out.println(" tandorii:300rs");
        System.out.println("spring rool:50rs");
        System.out.println(" chowmein:750rs");

    }

    public void icecream()
    {
        System.out.println(" strawberry:200rs");
        System.out.println(" chocolate:100rs");
        System.out.println(" mango:300rs");
        System.out.println("vanilla:50rs");
        System.out.println(" butterscoth:750rs");
    }
}

