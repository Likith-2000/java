package zoo.animal;
import java.util.Arrays;
public class Birds {
    String birdsString;
    
    
    String[] birdsStrings= {"budgies","cocktail","finches","parrot"};
    public String toString() {
          return "Animals present here are" +"["+ Arrays.toString(birdsStrings)+"]";
      
    }
    public void tiger()
    {
        System.out.println("budgies r");
    }
    public void peacock()
    {
        System.out.println("finces");
    }
    public void elephant()
    {
        System.out.println("cocktail ");
    }
    public void parrot()
    {
        System.out.println("parrot");
    }
 public static void main(String args[])
    {
       System.out.println("all birds are healthy"); 
    }
    
}
