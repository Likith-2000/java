package zoo.animal;

import java.util.Arrays;
java.lang.String;
public class Animal {

    public static void main(String args[]){
      String animalString;
     
      String[] animalStrings= {"elephant","tiger","zebra","leapord"};
      public String toString() {
    		return "Animals present here are" +"["+ Arrays.toString(animalString)+"]";	
      }
      public void tiger()
      {
    	  System.out.println("Tiger ");
      }
      public void lion()
      {
    	  System.out.println("lion");
      }
      public void elephant()
      {
    	  System.out.println("Elephant trumpet");
      }
      public void zebra()
      {
    	  System.out.println("zebra");
      }
    }
}


