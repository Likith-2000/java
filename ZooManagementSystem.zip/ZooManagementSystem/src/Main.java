import java.util.Scanner;
import zoo.animal.Animal;
import zoo.animal.Birds;
import zoo.food.FoodPriceList;
import zoo.food.Hotel


 public class Main{
	public static void main(String[] args) {
		Scanner myObj = new Scanner(System.in);
		String userName;
		System.out.println("WELCOME TO ZOO OF ");
		System.out.println("enter user name");
		userName = myObj.nextLine();
		System.out.println("hello"+ userName+"welcome to the zoo");
		
	}

 }











